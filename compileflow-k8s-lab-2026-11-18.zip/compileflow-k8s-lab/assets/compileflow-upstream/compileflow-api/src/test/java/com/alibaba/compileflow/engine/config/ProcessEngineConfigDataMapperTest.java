/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.compileflow.engine.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import com.alibaba.compileflow.engine.ProcessDataMapper;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ProcessEngineConfigDataMapperTest {
    @Test
    void explicitMapperIsPreservedInTheImmutableEngineConfiguration() {
        ProcessDataMapper mapper = new StubMapper();

        ProcessEngineConfig config = ProcessEngineConfig.builder().dataMapper(mapper).build();

        assertThat(config.getDataMapper()).isSameAs(mapper);
        assertThat(ProcessEngineConfig.defaults().getDataMapper()).isNull();
    }

    @Test
    void builderRejectsANullExplicitMapper() {
        assertThatThrownBy(() -> ProcessEngineConfig.builder().dataMapper(null))
            .isInstanceOf(NullPointerException.class)
            .hasMessage("dataMapper");
    }

    private static final class StubMapper implements ProcessDataMapper {
        @Override
        public Map<String, Object> toVariables(Object value) {
            return Map.of();
        }

        @Override
        public <T> T fromVariables(Map<String, Object> variables, Class<T> targetType) {
            return null;
        }
    }
}
