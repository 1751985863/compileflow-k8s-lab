/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.compileflow.engine.core.model.extension;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

class AbstractExtensionElementTest {
    @Test
    void qualifiedLookupSkipsAnUnqualifiedAttributeWithTheSameName() {
        ExtensionElement element = new ExtensionElement();
        ExtensionAttribute unqualified = new ExtensionAttribute("value");
        unqualified.setValue("plain");
        element.addAttribute(unqualified);
        ExtensionAttribute qualified = new ExtensionAttribute("value");
        qualified.setNamespacePrefix("cf");
        qualified.setValue("qualified");
        element.addAttribute(qualified);

        assertThat(element.getAttributeValue("cf", "value")).isEqualTo("qualified");
        assertThat(element.getAttributeValue("missing", "value")).isNull();
        assertThat(element.getAttributeValue("value")).isEqualTo("plain");
    }
}
