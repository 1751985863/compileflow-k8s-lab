/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.compileflow.engine.core.java.codegen;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

class GeneratedProcessNamesTest {
    @Test
    void placesProcessClassesInTheGeneratedProcessNamespace() {
        assertThat(GeneratedProcessNames.className("order.payment"))
            .isEqualTo("com.alibaba.compileflow.generated.process.order.PaymentFlow");
        assertThat(GeneratedProcessNames.className("hello")).isEqualTo(
                "com.alibaba.compileflow.generated.process.HelloFlow");
    }
}
